#!/usr/bin/env python3
"""Convenience entry point: `python run.py <command>`."""

from localmind.cli import main

if __name__ == "__main__":
    raise SystemExit(main())
