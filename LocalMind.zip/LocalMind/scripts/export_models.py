"""Fetch and compile the models LocalMind runs on.

Two paths:

1. ``--embedding`` pulls a MiniLM-class sentence encoder in ONNX form and,
   with ``--aihub``, compiles it for the Hexagon HTP through Qualcomm AI Hub.
2. ``--llm`` pulls a pre-quantized instruct model already built for ONNX
   Runtime GenAI.

This script is the only part of LocalMind that uses the network, and it runs
once at setup time. Nothing in the running application makes an outbound call.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

EMBED_REPO = "sentence-transformers/all-MiniLM-L6-v2"
EMBED_FILES = ["onnx/model.onnx", "tokenizer.json", "config.json"]
EMBED_DEST = ROOT / "models" / "embedding" / "all-MiniLM-L6-v2"

# Microsoft publishes Phi-3.5-mini pre-built for onnxruntime-genai.
# The cpu-int4 build runs anywhere; swap for a QNN build on Snapdragon.
LLM_REPO = "microsoft/Phi-3.5-mini-instruct-onnx"
LLM_SUBDIR = "cpu_and_mobile/cpu-int4-awq-block-128-acc-level-4"
LLM_DEST = ROOT / "models" / "llm" / "Phi-3.5-mini-instruct-onnx"


def _require(pkg: str, pip_name: str | None = None):
    try:
        return __import__(pkg)
    except ImportError:
        sys.exit(f"Missing dependency: pip install {pip_name or pkg}")


def export_embedding(use_aihub: bool) -> None:
    _require("huggingface_hub", "huggingface-hub")
    from huggingface_hub import hf_hub_download

    EMBED_DEST.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {EMBED_REPO} …")
    for remote in EMBED_FILES:
        local = hf_hub_download(repo_id=EMBED_REPO, filename=remote)
        target = EMBED_DEST / Path(remote).name
        target.write_bytes(Path(local).read_bytes())
        size_mb = target.stat().st_size / (1024 * 1024)
        print(f"  {target.name:<20} {size_mb:6.1f} MB")

    if not use_aihub:
        print(
            "\nDone (float ONNX). This runs on the NPU via the QNN EP, but "
            "compiling through AI Hub gives a faster, lower-power graph:\n"
            "  python scripts/export_models.py --embedding --aihub"
        )
        return

    compile_with_aihub()


def compile_with_aihub() -> None:
    """Compile the encoder into a Hexagon context binary via Qualcomm AI Hub.

    Requires an AI Hub account and a one-time ``qai-hub configure --api_token``.
    """
    _require("qai_hub", "qai-hub")
    import qai_hub as hub
    import torch
    from transformers import AutoModel, AutoTokenizer

    print("\nCompiling for Snapdragon via Qualcomm AI Hub …")
    seq_len = 256
    model = AutoModel.from_pretrained(EMBED_REPO).eval()
    tokenizer = AutoTokenizer.from_pretrained(EMBED_REPO)
    tokenizer.save_pretrained(EMBED_DEST)

    class Wrapped(torch.nn.Module):
        """Fold mean-pooling + L2 norm into the graph so the NPU does it too."""

        def __init__(self, base):
            super().__init__()
            self.base = base

        def forward(self, input_ids, attention_mask):
            out = self.base(input_ids=input_ids, attention_mask=attention_mask)
            hidden = out.last_hidden_state
            mask = attention_mask.unsqueeze(-1).float()
            pooled = (hidden * mask).sum(1) / mask.sum(1).clamp(min=1e-9)
            return torch.nn.functional.normalize(pooled, p=2, dim=1)

    wrapped = Wrapped(model).eval()
    example = (
        torch.ones((1, seq_len), dtype=torch.int64),
        torch.ones((1, seq_len), dtype=torch.int64),
    )
    traced = torch.jit.trace(wrapped, example)

    # Snapdragon X Elite is the target for HP's Copilot+ line.
    device = hub.Device("Snapdragon X Elite CRD")

    compile_job = hub.submit_compile_job(
        model=traced,
        device=device,
        input_specs={
            "input_ids": ((1, seq_len), "int64"),
            "attention_mask": ((1, seq_len), "int64"),
        },
        options="--target_runtime onnx --quantize_full_type w8a8",
    )
    print(f"  compile job: {compile_job.url}")
    compiled = compile_job.get_target_model()

    # Measure real on-device latency before shipping.
    profile_job = hub.submit_profile_job(model=compiled, device=device)
    print(f"  profile job: {profile_job.url}")
    summary = profile_job.download_profile()
    exec_us = summary["execution_summary"]["estimated_inference_time"]
    peak_mb = summary["execution_summary"]["estimated_inference_peak_memory"] / 1e6
    print(f"  on-device: {exec_us / 1000:.2f} ms/inference, {peak_mb:.1f} MB peak")

    compiled.download(str(EMBED_DEST / "model.onnx"))
    print(f"\nWrote NPU-compiled encoder to {EMBED_DEST / 'model.onnx'}")


def export_llm() -> None:
    _require("huggingface_hub", "huggingface-hub")
    from huggingface_hub import snapshot_download

    LLM_DEST.mkdir(parents=True, exist_ok=True)
    print(f"Downloading {LLM_REPO} / {LLM_SUBDIR} (~2 GB) …")
    path = snapshot_download(repo_id=LLM_REPO, allow_patterns=[f"{LLM_SUBDIR}/*"])
    src = Path(path) / LLM_SUBDIR
    for f in src.iterdir():
        if f.is_file():
            (LLM_DEST / f.name).write_bytes(f.read_bytes())
            print(f"  {f.name:<44} {f.stat().st_size / 1e6:8.1f} MB")
    print(f"\nWrote LLM to {LLM_DEST}")
    print(
        "\nOn a Snapdragon device, replace this with a QNN-targeted build and "
        "install onnxruntime-genai-qnn so generation lands on the Hexagon NPU."
    )


def main() -> int:
    p = argparse.ArgumentParser(description="Fetch/compile LocalMind models.")
    p.add_argument("--embedding", action="store_true", help="sentence encoder")
    p.add_argument("--llm", action="store_true", help="generative model")
    p.add_argument("--aihub", action="store_true", help="compile via Qualcomm AI Hub")
    p.add_argument("--all", action="store_true")
    args = p.parse_args()

    if not (args.embedding or args.llm or args.all):
        p.print_help()
        return 1
    if args.embedding or args.all:
        export_embedding(args.aihub)
    if args.llm or args.all:
        export_llm()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
