"""Tests for the parts that don't need model weights.

Run: pytest -q
"""

from __future__ import annotations

import numpy as np
import pytest

from localmind.config import Config
from localmind.ingest import loaders
from localmind.ingest.chunker import Chunk, chunk_document
from localmind.ingest.loaders import Block, LoadedDocument
from localmind.store.vector_store import VectorStore


# ------------------------------------------------------------------ normalize
def test_normalize_rejoins_hyphenated_linebreaks():
    assert "document" in loaders.normalize("This docu-\nment is confidential.")


def test_normalize_collapses_whitespace_and_blank_runs():
    out = loaders.normalize("a    b\n\n\n\nc")
    assert out == "a b\n\nc"


# -------------------------------------------------------------------- chunker
def _doc(blocks, doc_id="deadbeef", title="Test Doc"):
    return LoadedDocument(doc_id=doc_id, path=__file__, title=title, blocks=blocks)


def test_chunker_respects_target_size():
    text = " ".join(f"Sentence number {i} about clause {i}." for i in range(200))
    chunks = chunk_document(_doc([Block(text=text, page=1)]), target_chars=400)
    assert len(chunks) > 1
    # Allow the sentence-boundary slack a greedy packer needs.
    assert all(len(c.text) <= 400 * 1.7 for c in chunks)


def test_chunker_carries_overlap_between_chunks():
    text = " ".join(f"Alpha {i} beta gamma delta epsilon zeta." for i in range(60))
    chunks = chunk_document(
        _doc([Block(text=text, page=1)]), target_chars=300, overlap_chars=100
    )
    assert len(chunks) >= 2
    tail_words = set(chunks[0].text.split()[-6:])
    head_words = set(chunks[1].text.split()[:12])
    assert tail_words & head_words, "expected overlap between consecutive chunks"


def test_chunker_preserves_page_provenance():
    doc = _doc(
        [
            Block(text="Confidentiality survives termination." * 6, page=7),
            Block(text="Governing law is Delaware." * 6, page=9),
        ]
    )
    chunks = chunk_document(doc)
    assert {c.page for c in chunks} == {7, 9}
    assert any("p.7" in c.citation() for c in chunks)


def test_chunker_ids_are_unique_and_ordered():
    doc = _doc([Block(text="Lorem ipsum dolor sit amet. " * 40, page=1)])
    chunks = chunk_document(doc, target_chars=200)
    ids = [c.chunk_id for c in chunks]
    assert len(ids) == len(set(ids))
    assert [c.order for c in chunks] == list(range(len(chunks)))


def test_chunker_handles_empty_document():
    assert chunk_document(_doc([])) == []


def test_chunker_hard_splits_a_monster_sentence():
    giant = "x" * 5000  # no sentence boundaries at all
    chunks = chunk_document(_doc([Block(text=giant, page=1)]), target_chars=500)
    assert len(chunks) >= 8


# --------------------------------------------------------------- vector store
def _chunks(doc_id, n, title="Doc"):
    return [
        Chunk(
            chunk_id=f"{doc_id}:{i:05d}",
            doc_id=doc_id,
            doc_title=title,
            text=f"chunk {i}",
            page=i + 1,
            section=None,
            order=i,
        )
        for i in range(n)
    ]


def _unit(n, dim, seed=0):
    rng = np.random.default_rng(seed)
    v = rng.normal(size=(n, dim)).astype(np.float32)
    return v / np.linalg.norm(v, axis=1, keepdims=True)


def test_store_add_search_roundtrip(tmp_path):
    store = VectorStore(tmp_path / "idx", dim=16)
    chunks = _chunks("aaa", 5)
    vecs = _unit(5, 16)
    assert store.add(chunks, vecs) == 5

    hits = store.search(vecs[2], top_k=3)
    assert hits[0].chunk.chunk_id == "aaa:00002"
    assert hits[0].score == pytest.approx(1.0, abs=1e-5)


def test_store_persists_across_reload(tmp_path):
    path = tmp_path / "idx"
    store = VectorStore(path, dim=16)
    store.add(_chunks("bbb", 4), _unit(4, 16, seed=1))
    store.save()

    reloaded = VectorStore(path, dim=16).load()
    assert reloaded.stats()["chunks"] == 4
    assert reloaded.has_document("bbb")
    assert reloaded.chunks[1].doc_title == "Doc"


def test_store_reingest_replaces_rather_than_duplicates(tmp_path):
    store = VectorStore(tmp_path / "idx", dim=16)
    store.add(_chunks("ccc", 5), _unit(5, 16))
    store.add(_chunks("ccc", 3), _unit(3, 16, seed=2))
    assert store.stats()["chunks"] == 3
    assert store.manifest["ccc"]["n_chunks"] == 3


def test_store_forget_leaves_other_documents_intact(tmp_path):
    store = VectorStore(tmp_path / "idx", dim=16)
    store.add(_chunks("ddd", 3), _unit(3, 16))
    store.add(_chunks("eee", 4), _unit(4, 16, seed=3))

    assert store.remove_document("ddd") == 3
    assert store.stats()["chunks"] == 4
    assert not store.has_document("ddd")
    assert all(c.doc_id == "eee" for c in store.chunks)
    assert store.vectors.shape[0] == 4


def test_store_scopes_search_to_requested_documents(tmp_path):
    store = VectorStore(tmp_path / "idx", dim=16)
    a_vecs = _unit(3, 16, seed=4)
    store.add(_chunks("fff", 3), a_vecs)
    store.add(_chunks("ggg", 3), _unit(3, 16, seed=5))

    hits = store.search(a_vecs[0], top_k=5, doc_ids=["ggg"])
    assert hits and all(h.chunk.doc_id == "ggg" for h in hits)


def test_store_min_score_filters_weak_matches(tmp_path):
    store = VectorStore(tmp_path / "idx", dim=16)
    vecs = _unit(6, 16, seed=6)
    store.add(_chunks("hhh", 6), vecs)
    assert store.search(vecs[0], top_k=6, min_score=0.999)[0].chunk.order == 0
    assert len(store.search(vecs[0], top_k=6, min_score=0.999)) == 1


def test_search_on_empty_store_returns_nothing(tmp_path):
    store = VectorStore(tmp_path / "idx", dim=16)
    assert store.search(np.zeros(16, dtype=np.float32)) == []


# ---------------------------------------------------------------------- config
def test_config_roundtrip(tmp_path):
    path = tmp_path / "config.json"
    cfg = Config()
    cfg.retrieval.top_k = 11
    cfg.runtime.backend = "cpu"
    cfg.dump(path)

    loaded = Config.load(path)
    assert loaded.retrieval.top_k == 11
    assert loaded.runtime.backend == "cpu"


def test_config_defaults_when_file_absent(tmp_path):
    cfg = Config.load(tmp_path / "nope.json")
    assert cfg.embed.dim == 384
    assert cfg.server.host == "127.0.0.1"  # loopback by default


# ----------------------------------------------------------------------- npu
def test_provider_spec_cpu_has_no_qnn():
    from localmind import npu

    providers, opts = npu.provider_spec("cpu")
    assert providers == ["CPUExecutionProvider"]
    assert opts == [{}]


def test_provider_spec_qnn_sets_htp_options_and_cpu_fallback():
    from localmind import npu

    providers, opts = npu.provider_spec("qnn", performance_mode="burst")
    assert providers[0] == "QNNExecutionProvider"
    assert providers[-1] == "CPUExecutionProvider"
    assert opts[0]["backend_path"] == "QnnHtp.dll"
    assert opts[0]["htp_performance_mode"] == "burst"


def test_forcing_qnn_without_hardware_raises():
    from localmind import npu

    if npu.QNN_EP in npu._available_providers():
        pytest.skip("QNN actually available on this host")
    with pytest.raises(RuntimeError, match="QNNExecutionProvider"):
        npu.probe("qnn")


def test_auto_backend_falls_back_to_cpu_with_a_warning():
    from localmind import npu

    report = npu.probe("auto")
    assert report.selected_backend in {"qnn", "cpu"}
    if report.selected_backend == "cpu":
        assert any("CPU" in n for n in report.notes)


# ------------------------------------------------------------- prompt safety
def test_prompt_template_encloses_context_in_the_user_turn():
    from localmind.llm.engine import LLMEngine

    prompt = LLMEngine.build_chat_prompt("SYS RULES", "CONTEXT:\n[1] foo\n\nQUESTION: bar")
    assert prompt.index("SYS RULES") < prompt.index("CONTEXT:")
    assert prompt.rstrip().endswith("<|assistant|>")
