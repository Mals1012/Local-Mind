"""Local web UI served on loopback.

Binds to 127.0.0.1 by default and serves a single self-contained HTML page with
no external assets — no CDN, no font fetch, no analytics. The browser is just a
rendering surface for a process running on the user's own machine.
"""

from __future__ import annotations

import json
import logging
import shutil
import tempfile
from pathlib import Path
from typing import List, Optional

from .config import Config

log = logging.getLogger("localmind.server")

WEB_DIR = Path(__file__).resolve().parent.parent / "web"


def create_app(cfg: Optional[Config] = None):
    from fastapi import FastAPI, File, HTTPException, UploadFile
    from fastapi.responses import FileResponse, StreamingResponse
    from pydantic import BaseModel

    from .rag.pipeline import LocalMind

    cfg = cfg or Config.load()
    app = FastAPI(title="LocalMind", docs_url=None, redoc_url=None)
    engine = LocalMind(cfg)

    class AskRequest(BaseModel):
        question: str
        top_k: Optional[int] = None
        doc_ids: Optional[List[str]] = None

    # Deliberately no CORS middleware: only the page we serve may call the API.

    @app.get("/")
    def index():
        page = WEB_DIR / "index.html"
        if not page.exists():
            raise HTTPException(500, "web/index.html is missing")
        return FileResponse(page)

    @app.get("/api/health")
    def health():
        from . import npu

        report = npu.probe(cfg.runtime.backend)
        return {
            "ok": True,
            "backend": report.selected_backend,
            "npu": report.qnn_available,
            "providers": report.available_providers,
            "llm_loaded": engine.llm.is_loaded,
            **engine.stats(),
        }

    @app.get("/api/documents")
    def documents():
        return {"documents": engine.documents()}

    @app.post("/api/documents")
    async def upload(file: UploadFile = File(...)):
        suffix = Path(file.filename or "").suffix.lower()
        from .ingest.loaders import SUPPORTED_SUFFIXES

        if suffix not in SUPPORTED_SUFFIXES:
            raise HTTPException(400, f"Unsupported file type: {suffix}")

        # Staged in the OS temp dir, parsed, then deleted. The extracted text
        # lives only in the local index.
        tmp_dir = Path(tempfile.mkdtemp(prefix="localmind-"))
        tmp_path = tmp_dir / (file.filename or f"upload{suffix}")
        try:
            with tmp_path.open("wb") as fh:
                shutil.copyfileobj(file.file, fh)
            result = engine.ingest_file(tmp_path)
            return {
                "doc_id": result.doc_id,
                "title": result.title,
                "chunks": result.n_chunks,
                "skipped": result.skipped,
                "elapsed_s": round(result.elapsed_s, 2),
            }
        except Exception as exc:
            raise HTTPException(400, str(exc))
        finally:
            shutil.rmtree(tmp_dir, ignore_errors=True)

    @app.delete("/api/documents/{doc_id}")
    def forget(doc_id: str):
        removed = engine.forget(doc_id)
        if not removed:
            raise HTTPException(404, "Unknown document")
        return {"removed_chunks": removed}

    @app.post("/api/ask")
    def ask(req: AskRequest):
        def event_stream():
            for event in engine.ask_stream(
                req.question, top_k=req.top_k, doc_ids=req.doc_ids
            ):
                yield f"data: {json.dumps(event, ensure_ascii=False)}\n\n"

        return StreamingResponse(
            event_stream(),
            media_type="text/event-stream",
            headers={"Cache-Control": "no-store", "X-Accel-Buffering": "no"},
        )

    return app


def run(cfg: Optional[Config] = None, host: str = "127.0.0.1", port: int = 8756) -> None:
    import uvicorn

    cfg = cfg or Config.load()
    if host not in {"127.0.0.1", "localhost", "::1"}:
        log.warning(
            "Binding to %s exposes LocalMind beyond this device. "
            "Loopback is strongly recommended.",
            host,
        )
    print(f"\n  LocalMind running at http://{host}:{port}   (Ctrl-C to stop)\n")
    uvicorn.run(create_app(cfg), host=host, port=port, log_level="warning")
