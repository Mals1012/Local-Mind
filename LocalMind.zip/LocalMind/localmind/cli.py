"""LocalMind command-line interface."""

from __future__ import annotations

import argparse
import logging
import sys
from pathlib import Path

from .config import Config
from . import npu

BANNER = r"""
  _                    _ __  __ _         _
 | |   ___  __ __ _ | |  \/  (_)_ _  __| |
 | |__/ _ \/ _/ _` || | |\/| | | ' \/ _` |
 |____\___/\__\__,_||_|_|  |_|_|_||_\__,_|
 privacy-first document AI · on-device only
"""


def _setup_logging(verbose: bool) -> None:
    logging.basicConfig(
        level=logging.INFO if verbose else logging.WARNING,
        format="%(levelname)s %(name)s: %(message)s",
    )


def _pipeline(args):
    from .rag.pipeline import LocalMind

    return LocalMind(Config.load(args.config))


# ---------------------------------------------------------------- subcommands
def cmd_doctor(args) -> int:
    cfg = Config.load(args.config)
    print(BANNER)
    try:
        report = npu.probe(cfg.runtime.backend)
        print(report.pretty())
    except RuntimeError as exc:
        print(f"  Device probe failed: {exc}")
        return 1

    print("\nModel assets")
    print("-" * 46)
    for label, path in (
        ("embedding onnx", cfg.embed.onnx_path),
        ("embedding tok ", cfg.embed.tokenizer_path),
        ("llm directory ", cfg.llm.path),
    ):
        mark = "ok     " if path.exists() else "MISSING"
        print(f"  [{mark}] {label}  {path}")

    print("\nIndex")
    print("-" * 46)
    from .store.vector_store import VectorStore

    stats = VectorStore(cfg.store.path, cfg.embed.dim).load().stats()
    for k, v in stats.items():
        print(f"  {k:<12}: {v}")
    return 0


def cmd_ingest(args) -> int:
    lm = _pipeline(args)
    results = lm.ingest_path(args.path, force=args.force, progress=True)
    if not results:
        print("No supported documents found.", file=sys.stderr)
        return 1

    added = sum(r.n_chunks for r in results if not r.skipped)
    for r in results:
        tag = "skipped (unchanged)" if r.skipped else f"{r.n_chunks} chunks"
        print(f"  {r.title[:44]:<46} {tag:>20}  {r.elapsed_s:5.2f}s")
    print(f"\nIndexed {len(results)} document(s), {added} new chunks.")
    print("  " + "  ".join(f"{k}={v}" for k, v in lm.stats().items()))
    return 0


def cmd_ask(args) -> int:
    lm = _pipeline(args)
    question = " ".join(args.question)
    printed_sources = False

    for event in lm.ask_stream(question, top_k=args.top_k):
        if event["type"] == "sources":
            if args.show_sources:
                print("Sources")
                for s in event["sources"]:
                    print(f"  [{s['n']}] {s['citation']}  (score {s['score']:.3f})")
                print()
            printed_sources = True
        elif event["type"] == "token":
            print(event["text"], end="", flush=True)
        elif event["type"] == "error":
            print(f"\n{event['message']}", file=sys.stderr)
            return 1
        elif event["type"] == "done":
            stats = event.get("stats")
            if stats and args.stats:
                print(
                    f"\n\n  retrieval {stats['retrieval_ms']} ms · "
                    f"TTFT {stats['ttft_ms']} ms · "
                    f"{stats['tokens_per_second']} tok/s · "
                    f"{stats['completion_tokens']} tokens"
                )
    print()
    return 0 if printed_sources else 1


def cmd_chat(args) -> int:
    lm = _pipeline(args)
    print(BANNER)
    print("Ask about your documents. Ctrl-C or 'exit' to quit.\n")
    while True:
        try:
            question = input("you › ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0
        if question.lower() in {"exit", "quit", ":q"}:
            return 0
        if not question:
            continue
        print("\nlocalmind › ", end="", flush=True)
        for event in lm.ask_stream(question):
            if event["type"] == "token":
                print(event["text"], end="", flush=True)
            elif event["type"] == "error":
                print(event["message"])
        print("\n")


def cmd_list(args) -> int:
    lm = _pipeline(args)
    docs = lm.documents()
    if not docs:
        print("Index is empty.")
        return 0
    print(f"{'doc id':<18}{'chunks':>8}  title")
    print("-" * 70)
    for d in docs:
        print(f"{d['doc_id']:<18}{d['n_chunks']:>8}  {d['title'][:40]}")
    print()
    print("  " + "  ".join(f"{k}={v}" for k, v in lm.stats().items()))
    return 0


def cmd_forget(args) -> int:
    lm = _pipeline(args)
    if args.all:
        lm.store.clear()
        print("Index cleared. No document data remains on disk.")
        return 0
    removed = lm.forget(args.doc_id)
    print(f"Removed {removed} chunks for {args.doc_id}.")
    return 0 if removed else 1


def cmd_serve(args) -> int:
    from .server import run

    cfg = Config.load(args.config)
    run(cfg, host=args.host or cfg.server.host, port=args.port or cfg.server.port)
    return 0


def cmd_init(args) -> int:
    path = Config().dump(args.config)
    print(f"Wrote default configuration to {path}")
    return 0


# --------------------------------------------------------------------- parser
def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="localmind",
        description="Privacy-first, on-device AI document assistant for Snapdragon PCs.",
    )
    p.add_argument("-c", "--config", help="path to config.json")
    p.add_argument("-v", "--verbose", action="store_true")
    sub = p.add_subparsers(dest="command", required=True)

    d = sub.add_parser("doctor", help="check NPU, models and index health")
    d.set_defaults(func=cmd_doctor)

    i = sub.add_parser("ingest", help="index a file or a folder")
    i.add_argument("path")
    i.add_argument("--force", action="store_true", help="re-index even if unchanged")
    i.set_defaults(func=cmd_ingest)

    a = sub.add_parser("ask", help="ask a one-shot question")
    a.add_argument("question", nargs="+")
    a.add_argument("--top-k", type=int, default=None)
    a.add_argument("--show-sources", action="store_true", default=True)
    a.add_argument("--stats", action="store_true", help="print latency / throughput")
    a.set_defaults(func=cmd_ask)

    c = sub.add_parser("chat", help="interactive REPL")
    c.set_defaults(func=cmd_chat)

    l = sub.add_parser("list", help="list indexed documents")
    l.set_defaults(func=cmd_list)

    f = sub.add_parser("forget", help="remove a document from the index")
    f.add_argument("doc_id", nargs="?", default="")
    f.add_argument("--all", action="store_true")
    f.set_defaults(func=cmd_forget)

    s = sub.add_parser("serve", help="launch the local web UI")
    s.add_argument("--host", default=None)
    s.add_argument("--port", type=int, default=None)
    s.set_defaults(func=cmd_serve)

    n = sub.add_parser("init", help="write a default config.json")
    n.set_defaults(func=cmd_init)
    return p


def main(argv=None) -> int:
    args = build_parser().parse_args(argv)
    _setup_logging(args.verbose)
    try:
        return args.func(args)
    except KeyboardInterrupt:
        print()
        return 130
    except FileNotFoundError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        if args.verbose:
            raise
        print(f"error: {exc}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
