"""Hexagon NPU detection and ONNX Runtime execution-provider selection.

The whole point of LocalMind is that inference lands on the Snapdragon NPU
instead of a datacentre GPU. This module figures out whether the QNN execution
provider is actually usable on the current machine and builds the provider
option dictionaries ONNX Runtime expects.
"""

from __future__ import annotations

import logging
import platform
from dataclasses import dataclass
from typing import Any, Dict, List, Tuple

log = logging.getLogger("localmind.npu")

QNN_EP = "QNNExecutionProvider"
CPU_EP = "CPUExecutionProvider"


@dataclass
class DeviceReport:
    machine: str
    system: str
    available_providers: List[str]
    qnn_available: bool
    selected_backend: str
    notes: List[str]

    def pretty(self) -> str:
        lines = [
            "LocalMind device report",
            "-" * 46,
            f"  OS / arch        : {self.system} {self.machine}",
            f"  ORT providers    : {', '.join(self.available_providers) or 'none'}",
            f"  Hexagon NPU (QNN): {'yes' if self.qnn_available else 'no'}",
            f"  Selected backend : {self.selected_backend}",
        ]
        for note in self.notes:
            lines.append(f"  ! {note}")
        return "\n".join(lines)


def _available_providers() -> List[str]:
    try:
        import onnxruntime as ort
    except ImportError:
        return []
    try:
        return list(ort.get_available_providers())
    except Exception:  # pragma: no cover - defensive
        return []


def is_arm64_windows() -> bool:
    return platform.system() == "Windows" and platform.machine().lower() in {
        "arm64",
        "aarch64",
    }


def probe(backend: str = "auto") -> DeviceReport:
    """Inspect the machine and decide which backend to use."""
    providers = _available_providers()
    qnn = QNN_EP in providers
    notes: List[str] = []

    if not providers:
        notes.append(
            "onnxruntime is not importable — install onnxruntime-qnn (ARM64) "
            "or onnxruntime (x64 dev machine)."
        )

    backend = backend.lower()
    if backend == "qnn":
        if not qnn:
            raise RuntimeError(
                "runtime.backend='qnn' was requested but QNNExecutionProvider is "
                "not available. Install onnxruntime-qnn on a Snapdragon device, "
                "or set runtime.backend='auto'."
            )
        selected = "qnn"
    elif backend == "cpu":
        selected = "cpu"
    else:  # auto
        selected = "qnn" if qnn else "cpu"
        if not qnn:
            notes.append(
                "Falling back to CPU. Expect higher latency and materially worse "
                "battery life than the Hexagon NPU path."
            )
        if not is_arm64_windows() and qnn:
            notes.append("QNN reported on a non-ARM64 host — verify this is intentional.")

    return DeviceReport(
        machine=platform.machine(),
        system=platform.system(),
        available_providers=providers,
        qnn_available=qnn,
        selected_backend=selected,
        notes=notes,
    )


def provider_spec(
    backend: str,
    performance_mode: str = "burst",
    profiling: bool = False,
) -> Tuple[List[str], List[Dict[str, Any]]]:
    """Return ``(providers, provider_options)`` for ``ort.InferenceSession``.

    QNN options map onto the Hexagon HTP backend. ``htp_performance_mode``
    trades battery against latency; ``burst`` is right for short interactive
    document queries, ``balanced`` for long batch ingestion.
    """
    if backend == "qnn":
        qnn_opts: Dict[str, Any] = {
            "backend_path": "QnnHtp.dll",
            "htp_performance_mode": performance_mode,
            "htp_graph_finalization_optimization_mode": "3",
            "enable_htp_fp16_precision": "1",
        }
        if profiling:
            qnn_opts["profiling_level"] = "basic"
        # CPU stays in the list as a fallback for any op QNN cannot absorb.
        return [QNN_EP, CPU_EP], [qnn_opts, {}]
    return [CPU_EP], [{}]


def session_options(intra_op_threads: int = 0):
    import onnxruntime as ort

    so = ort.SessionOptions()
    so.graph_optimization_level = ort.GraphOptimizationLevel.ORT_ENABLE_ALL
    so.log_severity_level = 3
    if intra_op_threads > 0:
        so.intra_op_num_threads = intra_op_threads
    return so
