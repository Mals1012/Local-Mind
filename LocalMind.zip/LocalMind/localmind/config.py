"""Configuration loading for LocalMind.

Everything is local: paths resolve relative to the project root unless the user
supplies an absolute path. No environment lookups that phone home, no remote
config fetch.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Dict, Optional

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DEFAULT_CONFIG_PATH = PROJECT_ROOT / "config.json"


def _resolve(p: str | os.PathLike) -> Path:
    path = Path(p).expanduser()
    return path if path.is_absolute() else (PROJECT_ROOT / path).resolve()


@dataclass
class EmbedConfig:
    """Sentence-embedding model (runs on the NPU when QNN is available)."""

    model_dir: str = "models/embedding/all-MiniLM-L6-v2"
    onnx_file: str = "model.onnx"
    tokenizer_file: str = "tokenizer.json"
    max_seq_len: int = 256
    batch_size: int = 16
    dim: int = 384

    @property
    def onnx_path(self) -> Path:
        return _resolve(self.model_dir) / self.onnx_file

    @property
    def tokenizer_path(self) -> Path:
        return _resolve(self.model_dir) / self.tokenizer_file


@dataclass
class LLMConfig:
    """Generative model served through onnxruntime-genai."""

    model_dir: str = "models/llm/Phi-3.5-mini-instruct-onnx"
    max_new_tokens: int = 512
    temperature: float = 0.2
    top_p: float = 0.9
    repetition_penalty: float = 1.05
    # Prompt budget for retrieved context, in characters.
    context_char_budget: int = 6000

    @property
    def path(self) -> Path:
        return _resolve(self.model_dir)


@dataclass
class ChunkConfig:
    target_chars: int = 900
    overlap_chars: int = 150
    min_chars: int = 120


@dataclass
class RuntimeConfig:
    """Execution-provider preferences.

    ``backend`` is one of: ``auto`` (probe for the Hexagon NPU, fall back to
    CPU), ``qnn`` (force NPU, error out if unavailable), ``cpu``.
    """

    backend: str = "auto"
    qnn_performance_mode: str = "burst"  # burst | high_performance | balanced | power_saver
    qnn_profiling: bool = False
    intra_op_threads: int = 0  # 0 = let ORT decide


@dataclass
class StoreConfig:
    index_dir: str = "data/index"

    @property
    def path(self) -> Path:
        return _resolve(self.index_dir)


@dataclass
class ServerConfig:
    host: str = "127.0.0.1"  # loopback only — never bind 0.0.0.0
    port: int = 8756


@dataclass
class RetrievalConfig:
    top_k: int = 6
    min_score: float = 0.15


@dataclass
class Config:
    embed: EmbedConfig = field(default_factory=EmbedConfig)
    llm: LLMConfig = field(default_factory=LLMConfig)
    chunk: ChunkConfig = field(default_factory=ChunkConfig)
    runtime: RuntimeConfig = field(default_factory=RuntimeConfig)
    store: StoreConfig = field(default_factory=StoreConfig)
    server: ServerConfig = field(default_factory=ServerConfig)
    retrieval: RetrievalConfig = field(default_factory=RetrievalConfig)

    @classmethod
    def load(cls, path: Optional[str | os.PathLike] = None) -> "Config":
        cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
        if not cfg_path.exists():
            return cls()
        raw: Dict[str, Any] = json.loads(cfg_path.read_text(encoding="utf-8"))
        return cls(
            embed=EmbedConfig(**raw.get("embed", {})),
            llm=LLMConfig(**raw.get("llm", {})),
            chunk=ChunkConfig(**raw.get("chunk", {})),
            runtime=RuntimeConfig(**raw.get("runtime", {})),
            store=StoreConfig(**raw.get("store", {})),
            server=ServerConfig(**raw.get("server", {})),
            retrieval=RetrievalConfig(**raw.get("retrieval", {})),
        )

    def dump(self, path: Optional[str | os.PathLike] = None) -> Path:
        cfg_path = Path(path) if path else DEFAULT_CONFIG_PATH
        cfg_path.write_text(json.dumps(asdict(self), indent=2), encoding="utf-8")
        return cfg_path
