"""Retrieval-augmented generation pipeline."""
