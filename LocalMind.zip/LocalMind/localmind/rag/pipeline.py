"""The LocalMind pipeline: ingest documents, answer questions over them.

Everything runs in-process on the device. The only I/O is the local filesystem.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Dict, Iterator, List, Optional

from ..config import Config
from ..embed.embedder import Embedder
from ..ingest import loaders
from ..ingest.chunker import chunk_document
from ..llm.engine import LLMEngine, ModelNotInstalled
from ..store.vector_store import SearchHit, VectorStore

log = logging.getLogger("localmind.rag")

SYSTEM_PROMPT = """You are LocalMind, an offline document assistant running entirely on the user's device.

Rules:
- Answer only from the numbered CONTEXT passages below.
- Cite the passages you used with bracketed numbers, like [1] or [2][4].
- If the context does not contain the answer, say so plainly. Do not guess and do not draw on outside knowledge.
- Be concise and concrete. Quote exact figures, dates, clauses and names where the question calls for them."""


@dataclass
class IngestResult:
    path: Path
    doc_id: str
    title: str
    n_chunks: int
    n_chars: int
    elapsed_s: float
    skipped: bool = False


@dataclass
class Answer:
    question: str
    text: str
    hits: List[SearchHit] = field(default_factory=list)
    retrieval_ms: float = 0.0
    generation_stats: Optional[object] = None

    def sources(self) -> List[str]:
        return [h.citation() for h in self.hits]


class LocalMind:
    def __init__(self, cfg: Optional[Config] = None):
        self.cfg = cfg or Config.load()
        self.embedder = Embedder(self.cfg.embed, self.cfg.runtime)
        self.store = VectorStore(self.cfg.store.path, self.cfg.embed.dim).load()
        self.llm = LLMEngine(self.cfg.llm, self.cfg.runtime)

    # --------------------------------------------------------------- ingestion
    def ingest_file(
        self, path: str | Path, force: bool = False, progress: bool = False
    ) -> IngestResult:
        t0 = time.perf_counter()
        path = Path(path)
        doc = loaders.load(path)

        if not force and self.store.has_document(doc.doc_id):
            return IngestResult(
                path=path,
                doc_id=doc.doc_id,
                title=doc.title,
                n_chunks=self.store.manifest[doc.doc_id]["n_chunks"],
                n_chars=doc.char_count,
                elapsed_s=time.perf_counter() - t0,
                skipped=True,
            )

        chunks = chunk_document(
            doc,
            target_chars=self.cfg.chunk.target_chars,
            overlap_chars=self.cfg.chunk.overlap_chars,
            min_chars=self.cfg.chunk.min_chars,
        )
        if not chunks:
            raise ValueError(f"No extractable text in {path.name} (scanned image PDF?)")

        vectors = self.embedder.encode([c.text for c in chunks], show_progress=progress)
        self.store.add(chunks, vectors, source_path=str(path))
        self.store.save()

        return IngestResult(
            path=path,
            doc_id=doc.doc_id,
            title=doc.title,
            n_chunks=len(chunks),
            n_chars=doc.char_count,
            elapsed_s=time.perf_counter() - t0,
        )

    def ingest_path(
        self, path: str | Path, force: bool = False, progress: bool = False
    ) -> List[IngestResult]:
        results: List[IngestResult] = []
        for file_path in loaders.discover(path):
            try:
                results.append(self.ingest_file(file_path, force=force, progress=progress))
            except Exception as exc:
                log.error("Failed on %s: %s", file_path.name, exc)
        return results

    # --------------------------------------------------------------- retrieval
    def retrieve(
        self, question: str, top_k: Optional[int] = None, doc_ids=None
    ) -> tuple[List[SearchHit], float]:
        t0 = time.perf_counter()
        qvec = self.embedder.encode_one(question)
        hits = self.store.search(
            qvec,
            top_k=top_k or self.cfg.retrieval.top_k,
            min_score=self.cfg.retrieval.min_score,
            doc_ids=doc_ids,
        )
        return hits, (time.perf_counter() - t0) * 1000

    def _build_user_turn(self, question: str, hits: List[SearchHit]) -> str:
        budget = self.cfg.llm.context_char_budget
        used = 0
        parts: List[str] = []
        for i, hit in enumerate(hits, start=1):
            block = f"[{i}] ({hit.citation()})\n{hit.chunk.text}"
            if used + len(block) > budget and parts:
                break
            parts.append(block)
            used += len(block)
        context = "\n\n".join(parts) if parts else "(no matching passages)"
        return f"CONTEXT:\n{context}\n\nQUESTION: {question}"

    # ------------------------------------------------------------- generation
    def ask_stream(
        self, question: str, top_k: Optional[int] = None, doc_ids=None
    ) -> Iterator[Dict]:
        """Yield events: ``{'type': 'sources'|'token'|'done'|'error', ...}``."""
        if not self.store.chunks:
            yield {
                "type": "error",
                "message": "No documents indexed yet. Add one with: localmind ingest <file>",
            }
            return

        hits, retrieval_ms = self.retrieve(question, top_k=top_k, doc_ids=doc_ids)
        yield {
            "type": "sources",
            "retrieval_ms": round(retrieval_ms, 1),
            "backend": self.embedder.backend,
            "sources": [
                {
                    "n": i,
                    "citation": h.citation(),
                    "score": round(h.score, 4),
                    "preview": h.chunk.text[:220],
                }
                for i, h in enumerate(hits, start=1)
            ],
        }

        if not hits:
            yield {
                "type": "token",
                "text": "I couldn't find anything in the indexed documents that relates to that question.",
            }
            yield {"type": "done", "stats": None}
            return

        prompt = self.llm.build_chat_prompt(
            SYSTEM_PROMPT, self._build_user_turn(question, hits)
        )

        try:
            for piece in self.llm.stream(prompt):
                yield {"type": "token", "text": piece}
        except ModelNotInstalled as exc:
            yield {"type": "error", "message": str(exc)}
            return

        s = self.llm.last_stats
        yield {
            "type": "done",
            "stats": {
                "prompt_tokens": s.prompt_tokens,
                "completion_tokens": s.completion_tokens,
                "ttft_ms": round(s.ttft_ms, 1),
                "tokens_per_second": round(s.tokens_per_second, 2),
                "retrieval_ms": round(retrieval_ms, 1),
            },
        }

    def ask(self, question: str, top_k: Optional[int] = None, doc_ids=None) -> Answer:
        """Blocking convenience wrapper around :meth:`ask_stream`."""
        if not self.store.chunks:
            return Answer(
                question=question,
                text="No documents indexed yet. Add one with: localmind ingest <file>",
            )

        hits, retrieval_ms = self.retrieve(question, top_k=top_k, doc_ids=doc_ids)
        answer = Answer(question=question, text="", hits=hits, retrieval_ms=retrieval_ms)

        if not hits:
            answer.text = (
                "I couldn't find anything in the indexed documents "
                "that relates to that question."
            )
            return answer

        prompt = self.llm.build_chat_prompt(
            SYSTEM_PROMPT, self._build_user_turn(question, hits)
        )
        try:
            answer.text = self.llm.complete(prompt)
            answer.generation_stats = self.llm.last_stats
        except ModelNotInstalled as exc:
            answer.text = str(exc)
        return answer

    # ------------------------------------------------------------------ admin
    def documents(self) -> List[Dict]:
        return [
            {"doc_id": did, **meta} for did, meta in sorted(self.store.manifest.items())
        ]

    def forget(self, doc_id: str) -> int:
        removed = self.store.remove_document(doc_id)
        self.store.save()
        return removed

    def stats(self) -> Dict:
        return {**self.store.stats(), "embed_backend": self.embedder.backend}
