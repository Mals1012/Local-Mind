"""LocalMind — privacy-first, on-device AI document assistant for Snapdragon PCs."""

__version__ = "0.1.0"
__all__ = ["Config", "LocalMind"]


def __getattr__(name):
    # Lazy so `import localmind` stays instant and dependency-light.
    if name == "Config":
        from .config import Config
        return Config
    if name == "LocalMind":
        from .rag.pipeline import LocalMind
        return LocalMind
    raise AttributeError(name)
