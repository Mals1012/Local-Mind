"""Sentence embeddings via ONNX Runtime, accelerated on the Hexagon NPU.

Model: a quantized MiniLM-class encoder exported through Qualcomm AI Hub (see
``scripts/export_models.py``). Mean-pooled, L2-normalized, so cosine similarity
reduces to a dot product.
"""

from __future__ import annotations

import logging
import time
from pathlib import Path
from typing import List, Sequence

import numpy as np

from ..config import EmbedConfig, RuntimeConfig
from .. import npu

log = logging.getLogger("localmind.embed")


class Embedder:
    def __init__(self, cfg: EmbedConfig, runtime: RuntimeConfig):
        self.cfg = cfg
        self.runtime = runtime
        self._session = None
        self._tokenizer = None
        self._input_names: List[str] = []
        self.backend = "uninitialized"

    # ---------------------------------------------------------------- loading
    def load(self) -> "Embedder":
        if self._session is not None:
            return self

        import onnxruntime as ort
        from tokenizers import Tokenizer

        onnx_path: Path = self.cfg.onnx_path
        tok_path: Path = self.cfg.tokenizer_path
        if not onnx_path.exists():
            raise FileNotFoundError(
                f"Embedding model not found at {onnx_path}.\n"
                "Run: python scripts/export_models.py --embedding"
            )
        if not tok_path.exists():
            raise FileNotFoundError(f"Tokenizer not found at {tok_path}")

        report = npu.probe(self.runtime.backend)
        providers, provider_opts = npu.provider_spec(
            report.selected_backend,
            self.runtime.qnn_performance_mode,
            self.runtime.qnn_profiling,
        )
        so = npu.session_options(self.runtime.intra_op_threads)

        t0 = time.perf_counter()
        try:
            self._session = ort.InferenceSession(
                str(onnx_path),
                sess_options=so,
                providers=providers,
                provider_options=provider_opts,
            )
            self.backend = report.selected_backend
        except Exception as exc:
            if report.selected_backend != "qnn":
                raise
            log.warning("QNN session failed (%s) — retrying on CPU", exc)
            cpu_p, cpu_o = npu.provider_spec("cpu")
            self._session = ort.InferenceSession(
                str(onnx_path), sess_options=so, providers=cpu_p, provider_options=cpu_o
            )
            self.backend = "cpu"

        self._input_names = [i.name for i in self._session.get_inputs()]

        self._tokenizer = Tokenizer.from_file(str(tok_path))
        self._tokenizer.enable_truncation(max_length=self.cfg.max_seq_len)
        self._tokenizer.enable_padding(
            length=self.cfg.max_seq_len, pad_id=0, pad_token="[PAD]"
        )

        log.info(
            "Embedder ready on %s in %.0f ms",
            self.backend.upper(),
            (time.perf_counter() - t0) * 1000,
        )
        return self

    # -------------------------------------------------------------- inference
    def _feed(self, texts: Sequence[str]) -> dict:
        encodings = self._tokenizer.encode_batch(list(texts))
        ids = np.array([e.ids for e in encodings], dtype=np.int64)
        mask = np.array([e.attention_mask for e in encodings], dtype=np.int64)
        feed = {}
        if "input_ids" in self._input_names:
            feed["input_ids"] = ids
        if "attention_mask" in self._input_names:
            feed["attention_mask"] = mask
        if "token_type_ids" in self._input_names:
            feed["token_type_ids"] = np.zeros_like(ids)
        return feed

    @staticmethod
    def _mean_pool(hidden: np.ndarray, mask: np.ndarray) -> np.ndarray:
        m = mask[..., None].astype(np.float32)
        summed = (hidden * m).sum(axis=1)
        counts = np.clip(m.sum(axis=1), 1e-9, None)
        return summed / counts

    @staticmethod
    def _l2(vectors: np.ndarray) -> np.ndarray:
        norms = np.linalg.norm(vectors, axis=1, keepdims=True)
        return vectors / np.clip(norms, 1e-12, None)

    def encode(self, texts: Sequence[str], show_progress: bool = False) -> np.ndarray:
        """Embed ``texts`` into an ``(n, dim)`` float32 matrix of unit vectors."""
        if self._session is None:
            self.load()
        if not texts:
            return np.zeros((0, self.cfg.dim), dtype=np.float32)

        out: List[np.ndarray] = []
        bs = max(1, self.cfg.batch_size)
        total = len(texts)

        for start in range(0, total, bs):
            batch = list(texts[start : start + bs])
            feed = self._feed(batch)
            raw = self._session.run(None, feed)[0]

            if raw.ndim == 3:  # (batch, seq, dim) -> pool
                vecs = self._mean_pool(raw.astype(np.float32), feed["attention_mask"])
            else:  # model already emits a pooled sentence vector
                vecs = raw.astype(np.float32)

            out.append(self._l2(vecs))
            if show_progress:
                done = min(start + bs, total)
                print(f"\r  embedding {done}/{total}", end="", flush=True)

        if show_progress:
            print()
        return np.vstack(out).astype(np.float32)

    def encode_one(self, text: str) -> np.ndarray:
        return self.encode([text])[0]
