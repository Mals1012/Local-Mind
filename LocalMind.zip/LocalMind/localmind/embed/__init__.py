"""NPU-accelerated embeddings."""
