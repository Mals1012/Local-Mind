"""Document parsing and chunking."""
