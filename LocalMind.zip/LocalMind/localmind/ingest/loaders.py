"""Local document parsing. Nothing here touches the network.

Each loader yields ``Block`` objects that carry the text plus enough provenance
(page number, heading, paragraph index) for the answer to cite its source.
"""

from __future__ import annotations

import hashlib
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List

SUPPORTED_SUFFIXES = {".pdf", ".docx", ".txt", ".md", ".markdown"}


@dataclass
class Block:
    text: str
    page: int | None = None
    section: str | None = None
    order: int = 0


@dataclass
class LoadedDocument:
    doc_id: str
    path: Path
    title: str
    blocks: List[Block]
    n_pages: int | None = None

    @property
    def char_count(self) -> int:
        return sum(len(b.text) for b in self.blocks)


class UnsupportedDocument(ValueError):
    pass


def file_fingerprint(path: Path) -> str:
    """Content hash — re-ingesting an unchanged file is a no-op."""
    h = hashlib.sha256()
    h.update(path.name.encode("utf-8"))
    with path.open("rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:16]


_WS = re.compile(r"[ \t\u00a0]+")
_NEWLINES = re.compile(r"\n{3,}")
# Words split across a line break by PDF hyphenation: "docu-\nment" -> "document"
_DEHYPHEN = re.compile(r"(\w)-\n(\w)")


def normalize(text: str) -> str:
    text = text.replace("\r\n", "\n").replace("\r", "\n")
    text = _DEHYPHEN.sub(r"\1\2", text)
    text = _WS.sub(" ", text)
    text = _NEWLINES.sub("\n\n", text)
    return text.strip()


def _load_pdf(path: Path) -> LoadedDocument:
    try:
        from pypdf import PdfReader
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError("pypdf is required for PDF support: pip install pypdf") from exc

    reader = PdfReader(str(path))
    blocks: List[Block] = []
    order = 0
    for page_no, page in enumerate(reader.pages, start=1):
        raw = page.extract_text() or ""
        text = normalize(raw)
        if not text:
            continue
        # Split a page into paragraph-sized blocks so retrieval stays granular.
        for para in (p.strip() for p in text.split("\n\n")):
            if not para:
                continue
            blocks.append(Block(text=para, page=page_no, order=order))
            order += 1

    title = (reader.metadata.title if reader.metadata else None) or path.stem
    return LoadedDocument(
        doc_id=file_fingerprint(path),
        path=path,
        title=str(title).strip() or path.stem,
        blocks=blocks,
        n_pages=len(reader.pages),
    )


def _load_docx(path: Path) -> LoadedDocument:
    try:
        import docx  # python-docx
    except ImportError as exc:  # pragma: no cover
        raise RuntimeError(
            "python-docx is required for .docx support: pip install python-docx"
        ) from exc

    document = docx.Document(str(path))
    blocks: List[Block] = []
    current_section: str | None = None
    order = 0

    for para in document.paragraphs:
        text = normalize(para.text)
        if not text:
            continue
        style = (para.style.name or "").lower() if para.style else ""
        if style.startswith("heading") or style == "title":
            current_section = text
            # Headings are kept as blocks too — they often answer "what is X about".
            blocks.append(Block(text=text, section=current_section, order=order))
            order += 1
            continue
        blocks.append(Block(text=text, section=current_section, order=order))
        order += 1

    # Tables are flattened row-wise; losing them loses most contracts and invoices.
    for table in document.tables:
        rows = []
        for row in table.rows:
            cells = [normalize(c.text) for c in row.cells]
            if any(cells):
                rows.append(" | ".join(cells))
        if rows:
            blocks.append(
                Block(text="\n".join(rows), section=current_section, order=order)
            )
            order += 1

    return LoadedDocument(
        doc_id=file_fingerprint(path),
        path=path,
        title=path.stem,
        blocks=blocks,
    )


_MD_HEADING = re.compile(r"^(#{1,6})\s+(.*)$")


def _load_text(path: Path) -> LoadedDocument:
    raw = path.read_text(encoding="utf-8", errors="replace")
    blocks: List[Block] = []
    section: str | None = None
    order = 0
    for para in normalize(raw).split("\n\n"):
        para = para.strip()
        if not para:
            continue
        head = _MD_HEADING.match(para.split("\n", 1)[0])
        if head:
            section = head.group(2).strip()
        blocks.append(Block(text=para, section=section, order=order))
        order += 1
    return LoadedDocument(
        doc_id=file_fingerprint(path),
        path=path,
        title=path.stem,
        blocks=blocks,
    )


def load(path: str | Path) -> LoadedDocument:
    path = Path(path).expanduser().resolve()
    if not path.exists():
        raise FileNotFoundError(path)
    suffix = path.suffix.lower()
    if suffix == ".pdf":
        return _load_pdf(path)
    if suffix == ".docx":
        return _load_docx(path)
    if suffix in {".txt", ".md", ".markdown"}:
        return _load_text(path)
    raise UnsupportedDocument(
        f"{suffix or '(no extension)'} is not supported. "
        f"Supported: {', '.join(sorted(SUPPORTED_SUFFIXES))}"
    )


def discover(root: str | Path, recursive: bool = True) -> Iterable[Path]:
    """Yield every supported document under ``root``."""
    root = Path(root).expanduser().resolve()
    if root.is_file():
        yield root
        return
    pattern = "**/*" if recursive else "*"
    for p in sorted(root.glob(pattern)):
        if p.is_file() and p.suffix.lower() in SUPPORTED_SUFFIXES:
            yield p
