"""Turn parsed blocks into overlapping, retrieval-sized chunks.

Chunk boundaries follow sentence boundaries where possible. A chunk that splits
mid-clause retrieves badly and reads worse when quoted back as a citation.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Dict, List, Sequence

from .loaders import Block, LoadedDocument

_SENTENCE_END = re.compile(r"(?<=[.!?])\s+(?=[A-Z0-9\"'(\[])")


@dataclass
class Chunk:
    chunk_id: str
    doc_id: str
    doc_title: str
    text: str
    page: int | None
    section: str | None
    order: int

    def to_dict(self) -> Dict:
        return asdict(self)

    def citation(self) -> str:
        if self.page is not None:
            return f"{self.doc_title}, p.{self.page}"
        if self.section:
            return f"{self.doc_title} — {self.section}"
        return self.doc_title


def _split_sentences(text: str) -> List[str]:
    parts = [s.strip() for s in _SENTENCE_END.split(text) if s.strip()]
    return parts or ([text.strip()] if text.strip() else [])


def _pack(
    sentences: Sequence[str],
    target_chars: int,
    overlap_chars: int,
    min_chars: int,
) -> List[str]:
    """Greedily pack sentences up to ``target_chars`` with a trailing overlap."""
    out: List[str] = []
    buf: List[str] = []
    size = 0

    for sent in sentences:
        # A single monster sentence (tables, minified text) gets hard-split.
        if len(sent) > target_chars * 1.6:
            if buf:
                out.append(" ".join(buf))
                buf, size = [], 0
            for i in range(0, len(sent), target_chars):
                out.append(sent[i : i + target_chars])
            continue

        if size + len(sent) + 1 > target_chars and buf:
            out.append(" ".join(buf))
            # Carry the tail of the finished chunk into the next one.
            carry: List[str] = []
            carried = 0
            for prev in reversed(buf):
                if carried + len(prev) > overlap_chars:
                    break
                carry.insert(0, prev)
                carried += len(prev) + 1
            buf = carry
            size = carried

        buf.append(sent)
        size += len(sent) + 1

    if buf:
        tail = " ".join(buf)
        # Don't emit a sliver — fold it back into the previous chunk.
        if out and len(tail) < min_chars:
            out[-1] = f"{out[-1]} {tail}"
        else:
            out.append(tail)
    return out


def chunk_document(
    doc: LoadedDocument,
    target_chars: int = 900,
    overlap_chars: int = 150,
    min_chars: int = 120,
) -> List[Chunk]:
    chunks: List[Chunk] = []

    # Group consecutive blocks that share a page/section so short paragraphs
    # merge into one useful chunk instead of a dozen useless ones.
    groups: List[tuple[int | None, str | None, List[Block]]] = []
    for block in doc.blocks:
        key = (block.page, block.section)
        if groups and (groups[-1][0], groups[-1][1]) == key:
            groups[-1][2].append(block)
        else:
            groups.append((block.page, block.section, [block]))

    idx = 0
    for page, section, blocks in groups:
        text = "\n".join(b.text for b in blocks).strip()
        if not text:
            continue
        for piece in _pack(
            _split_sentences(text), target_chars, overlap_chars, min_chars
        ):
            piece = piece.strip()
            if not piece:
                continue
            chunks.append(
                Chunk(
                    chunk_id=f"{doc.doc_id}:{idx:05d}",
                    doc_id=doc.doc_id,
                    doc_title=doc.title,
                    text=piece,
                    page=page,
                    section=section,
                    order=idx,
                )
            )
            idx += 1

    return chunks
