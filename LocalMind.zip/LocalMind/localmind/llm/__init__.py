"""Local generative inference."""
