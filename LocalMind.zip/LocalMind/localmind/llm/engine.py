"""Generative inference through onnxruntime-genai on the Snapdragon NPU.

The model is a 4-bit quantized instruct model compiled for the Hexagon HTP.
Tokens stream out as they are produced so the UI shows a first token in well
under a second rather than blocking for the full completion.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterator, List, Optional

from ..config import LLMConfig, RuntimeConfig

log = logging.getLogger("localmind.llm")


@dataclass
class GenerationStats:
    prompt_tokens: int = 0
    completion_tokens: int = 0
    ttft_ms: float = 0.0
    total_ms: float = 0.0

    @property
    def tokens_per_second(self) -> float:
        gen_ms = max(self.total_ms - self.ttft_ms, 1e-6)
        return self.completion_tokens / (gen_ms / 1000.0)

    def pretty(self) -> str:
        return (
            f"{self.completion_tokens} tok · "
            f"TTFT {self.ttft_ms:.0f} ms · "
            f"{self.tokens_per_second:.1f} tok/s"
        )


class ModelNotInstalled(RuntimeError):
    pass


class LLMEngine:
    """Thin wrapper over onnxruntime-genai with a stable streaming interface."""

    def __init__(self, cfg: LLMConfig, runtime: RuntimeConfig):
        self.cfg = cfg
        self.runtime = runtime
        self._og = None
        self._model = None
        self._tokenizer = None
        self._stream = None
        self.last_stats = GenerationStats()

    # ---------------------------------------------------------------- loading
    def load(self) -> "LLMEngine":
        if self._model is not None:
            return self

        model_path: Path = self.cfg.path
        if not model_path.exists() or not any(model_path.glob("*.onnx")):
            raise ModelNotInstalled(
                f"No ONNX model found in {model_path}.\n"
                "Export one for your device first:\n"
                "  python scripts/export_models.py --llm\n"
                "See README.md § Model setup."
            )

        try:
            import onnxruntime_genai as og
        except ImportError as exc:
            raise ModelNotInstalled(
                "onnxruntime-genai is not installed.\n"
                "  Snapdragon (ARM64): pip install onnxruntime-genai-qnn\n"
                "  x64 dev machine   : pip install onnxruntime-genai"
            ) from exc

        t0 = time.perf_counter()
        self._og = og
        self._model = og.Model(str(model_path))
        self._tokenizer = og.Tokenizer(self._model)
        self._stream = self._tokenizer.create_stream()
        log.info(
            "LLM loaded from %s in %.1f s", model_path.name, time.perf_counter() - t0
        )
        return self

    @property
    def is_loaded(self) -> bool:
        return self._model is not None

    # ------------------------------------------------------------ prompt form
    @staticmethod
    def build_chat_prompt(system: str, user: str) -> str:
        """Phi-3 / Llama-3-style chat template.

        Kept explicit rather than delegated to a tokenizer template so the exact
        prompt is auditable — which matters when the selling point is that
        nothing unexpected leaves the device.
        """
        return (
            f"<|system|>\n{system.strip()}<|end|>\n"
            f"<|user|>\n{user.strip()}<|end|>\n"
            f"<|assistant|>\n"
        )

    # -------------------------------------------------------------- inference
    def stream(
        self,
        prompt: str,
        max_new_tokens: Optional[int] = None,
        stop: Optional[List[str]] = None,
    ) -> Iterator[str]:
        """Yield decoded text fragments as the NPU produces them."""
        if not self.is_loaded:
            self.load()

        og = self._og
        stop = stop or ["<|end|>", "<|user|>", "<|endoftext|>"]
        max_new = max_new_tokens or self.cfg.max_new_tokens

        input_tokens = self._tokenizer.encode(prompt)
        n_prompt = len(input_tokens)

        params = og.GeneratorParams(self._model)
        params.set_search_options(
            max_length=n_prompt + max_new,
            temperature=self.cfg.temperature,
            top_p=self.cfg.top_p,
            repetition_penalty=self.cfg.repetition_penalty,
            do_sample=self.cfg.temperature > 0.0,
        )

        # onnxruntime-genai moved token input from GeneratorParams onto
        # Generator.append_tokens around 0.5. Support both.
        try:
            generator = og.Generator(self._model, params)
            generator.append_tokens(input_tokens)
        except AttributeError:  # pragma: no cover - older runtime
            params.input_ids = input_tokens
            generator = og.Generator(self._model, params)

        stats = GenerationStats(prompt_tokens=n_prompt)
        t0 = time.perf_counter()
        first_token_at: Optional[float] = None
        buffer = ""

        try:
            while not generator.is_done():
                generator.generate_next_token()
                token = generator.get_next_tokens()[0]

                if first_token_at is None:
                    first_token_at = time.perf_counter()
                    stats.ttft_ms = (first_token_at - t0) * 1000

                piece = self._stream.decode(token)
                stats.completion_tokens += 1
                if not piece:
                    continue

                buffer += piece
                hit_stop = next((s for s in stop if s in buffer), None)
                if hit_stop:
                    tail = buffer.split(hit_stop)[0]
                    emitted = len(buffer) - len(piece)
                    if len(tail) > emitted:
                        yield tail[emitted:]
                    break

                yield piece

                if stats.completion_tokens >= max_new:
                    break
        finally:
            stats.total_ms = (time.perf_counter() - t0) * 1000
            self.last_stats = stats
            try:
                del generator
            except Exception:  # pragma: no cover
                pass

    def complete(self, prompt: str, max_new_tokens: Optional[int] = None) -> str:
        return "".join(self.stream(prompt, max_new_tokens=max_new_tokens))
