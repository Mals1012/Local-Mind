"""A small, dependency-light vector index persisted to disk.

Deliberately plain NumPy rather than FAISS: a personal document corpus is
thousands of chunks, not billions, and a brute-force dot product over a
normalized float32 matrix is sub-millisecond at that scale while keeping the
RAM footprint and the install story small — both of which matter on a fanless
Snapdragon laptop.
"""

from __future__ import annotations

import json
import logging
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterable, List, Optional, Sequence

import numpy as np

from ..ingest.chunker import Chunk

log = logging.getLogger("localmind.store")

VECTORS_FILE = "vectors.npy"
META_FILE = "chunks.jsonl"
MANIFEST_FILE = "manifest.json"


@dataclass
class SearchHit:
    score: float
    chunk: Chunk

    def citation(self) -> str:
        return self.chunk.citation()


class VectorStore:
    def __init__(self, index_dir: Path, dim: int = 384):
        self.dir = Path(index_dir)
        self.dim = dim
        self.vectors: np.ndarray = np.zeros((0, dim), dtype=np.float32)
        self.chunks: List[Chunk] = []
        self.manifest: Dict[str, dict] = {}  # doc_id -> {title, path, n_chunks}

    # ------------------------------------------------------------ persistence
    def load(self) -> "VectorStore":
        if not self.dir.exists():
            return self
        vpath = self.dir / VECTORS_FILE
        mpath = self.dir / META_FILE
        if vpath.exists() and mpath.exists():
            self.vectors = np.load(vpath).astype(np.float32)
            self.chunks = [
                Chunk(**json.loads(line))
                for line in mpath.read_text(encoding="utf-8").splitlines()
                if line.strip()
            ]
            if len(self.chunks) != self.vectors.shape[0]:
                raise RuntimeError(
                    f"Index corrupt: {self.vectors.shape[0]} vectors vs "
                    f"{len(self.chunks)} chunks. Delete {self.dir} and re-ingest."
                )
            self.dim = self.vectors.shape[1] if self.vectors.size else self.dim
        man = self.dir / MANIFEST_FILE
        if man.exists():
            self.manifest = json.loads(man.read_text(encoding="utf-8"))
        log.info("Loaded %d chunks from %d documents", len(self.chunks), len(self.manifest))
        return self

    def save(self) -> None:
        self.dir.mkdir(parents=True, exist_ok=True)
        np.save(self.dir / VECTORS_FILE, self.vectors)
        with (self.dir / META_FILE).open("w", encoding="utf-8") as fh:
            for c in self.chunks:
                fh.write(json.dumps(c.to_dict(), ensure_ascii=False) + "\n")
        (self.dir / MANIFEST_FILE).write_text(
            json.dumps(self.manifest, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    # ---------------------------------------------------------------- mutation
    def has_document(self, doc_id: str) -> bool:
        return doc_id in self.manifest

    def add(
        self,
        chunks: Sequence[Chunk],
        vectors: np.ndarray,
        source_path: Optional[str] = None,
    ) -> int:
        if len(chunks) == 0:
            return 0
        if vectors.shape[0] != len(chunks):
            raise ValueError("vector/chunk count mismatch")

        doc_id = chunks[0].doc_id
        if self.has_document(doc_id):
            self.remove_document(doc_id)

        vectors = vectors.astype(np.float32)
        self.vectors = (
            vectors if self.vectors.size == 0 else np.vstack([self.vectors, vectors])
        )
        self.chunks.extend(chunks)
        self.manifest[doc_id] = {
            "title": chunks[0].doc_title,
            "path": source_path or "",
            "n_chunks": len(chunks),
        }
        return len(chunks)

    def remove_document(self, doc_id: str) -> int:
        keep = [i for i, c in enumerate(self.chunks) if c.doc_id != doc_id]
        removed = len(self.chunks) - len(keep)
        if removed:
            self.vectors = (
                self.vectors[keep] if keep else np.zeros((0, self.dim), dtype=np.float32)
            )
            self.chunks = [self.chunks[i] for i in keep]
        self.manifest.pop(doc_id, None)
        return removed

    def clear(self) -> None:
        self.vectors = np.zeros((0, self.dim), dtype=np.float32)
        self.chunks = []
        self.manifest = {}
        if self.dir.exists():
            shutil.rmtree(self.dir)

    # ------------------------------------------------------------------ search
    def search(
        self,
        query_vec: np.ndarray,
        top_k: int = 6,
        min_score: float = 0.0,
        doc_ids: Optional[Iterable[str]] = None,
    ) -> List[SearchHit]:
        if self.vectors.shape[0] == 0:
            return []

        mask_idx = None
        if doc_ids is not None:
            allowed = set(doc_ids)
            mask_idx = np.array(
                [i for i, c in enumerate(self.chunks) if c.doc_id in allowed],
                dtype=np.int64,
            )
            if mask_idx.size == 0:
                return []
            matrix = self.vectors[mask_idx]
        else:
            matrix = self.vectors

        # Both sides are unit-normalized, so this dot product *is* cosine sim.
        scores = matrix @ query_vec.astype(np.float32)
        k = min(top_k, scores.shape[0])
        top = np.argpartition(-scores, k - 1)[:k]
        top = top[np.argsort(-scores[top])]

        hits: List[SearchHit] = []
        for local_i in top:
            score = float(scores[local_i])
            if score < min_score:
                continue
            global_i = int(mask_idx[local_i]) if mask_idx is not None else int(local_i)
            hits.append(SearchHit(score=score, chunk=self.chunks[global_i]))
        return hits

    # ------------------------------------------------------------------- stats
    def stats(self) -> Dict[str, object]:
        mb = self.vectors.nbytes / (1024 * 1024)
        return {
            "documents": len(self.manifest),
            "chunks": len(self.chunks),
            "dim": int(self.vectors.shape[1]) if self.vectors.size else self.dim,
            "index_mb": round(mb, 2),
        }
