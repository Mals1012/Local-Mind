"""On-disk vector index."""
